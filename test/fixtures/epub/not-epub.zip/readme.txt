Just an ordinary archive, nothing bookish about it.
